// src/shared/viewHelpers.js
function fmtIDR(v) {
  if (v === null || v === undefined || v === "") return "-";
  const n = Number(v);
  if (Number.isNaN(n)) return String(v);
  return "Rp " + n.toLocaleString("id-ID");
}

function fmtDate(d) {
  if (!d) return "-";
  const s = String(d).slice(0, 10); // YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  return String(d);
}

function roomStatusBadgeClass(status) {
  const s = String(status || "").toUpperCase();
  if (s === "AVAILABLE") return "text-bg-success";
  if (s === "MAINTENANCE") return "text-bg-warning";
  if (s === "INACTIVE") return "text-bg-secondary";
  return "text-bg-secondary";
}

function amenityConditionBadgeClass(condition) {
  const c = String(condition || "").toUpperCase();
  if (!c) return "text-muted";
  if (c === "NEW" || c === "GOOD") return "text-bg-success";
  if (c === "FAIR" || c === "DAMAGED") return "text-bg-warning";
  if (c === "MISSING") return "text-bg-danger";
  return "text-bg-secondary";
}

module.exports = {
  fmtIDR,
  fmtDate,
  roomStatusBadgeClass,
  amenityConditionBadgeClass,
};
