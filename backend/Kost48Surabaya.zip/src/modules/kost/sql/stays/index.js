// modules/kost/sql/stays/index.js
module.exports = {
  ...require("./stays.sql"),
};
