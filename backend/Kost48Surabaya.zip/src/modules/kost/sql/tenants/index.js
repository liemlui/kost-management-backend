// modules/kost/sql/tenants/index.js
module.exports = {
  ...require("./tenants.sql"),
};
