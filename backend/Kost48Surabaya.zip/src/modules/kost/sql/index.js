// pwe/backend/src/modules/kost/sql/index.js

module.exports = {
  rooms: require("./rooms"),
  tenants: require("./tenants"),
  stays: require("./stays"),
  billing: require("./billing"),
  ops: require("./ops"),
  inventory: require("./inventory"),
  assets: require("./assets"),

};
