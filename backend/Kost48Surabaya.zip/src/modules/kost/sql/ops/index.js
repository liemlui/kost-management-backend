// modules/kost/sql/ops/index.js
module.exports = {
  ...require("./audit.sql"),
  ...require("./overdue.sql"),
};
