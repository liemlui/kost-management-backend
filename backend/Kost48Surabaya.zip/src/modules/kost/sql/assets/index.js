// pwe/backend/src/modules/kost/sql/assets/index.js
const roomAssets = require("./roomAssets.sql");

module.exports = { roomAssets };
